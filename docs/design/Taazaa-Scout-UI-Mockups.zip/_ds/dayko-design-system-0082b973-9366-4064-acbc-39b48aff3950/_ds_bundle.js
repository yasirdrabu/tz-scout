/* @ds-bundle: {"format":4,"namespace":"DaykoDesignSystem_0082b9","components":[{"name":"Avatar","sourcePath":"components/core/Avatar.jsx"},{"name":"Badge","sourcePath":"components/core/Badge.jsx"},{"name":"Button","sourcePath":"components/core/Button.jsx"},{"name":"Card","sourcePath":"components/core/Card.jsx"},{"name":"CardHeader","sourcePath":"components/core/Card.jsx"},{"name":"CardBody","sourcePath":"components/core/Card.jsx"},{"name":"CardFooter","sourcePath":"components/core/Card.jsx"},{"name":"Chip","sourcePath":"components/core/Chip.jsx"},{"name":"IconButton","sourcePath":"components/core/IconButton.jsx"},{"name":"ProductMark","sourcePath":"components/core/ProductMark.jsx"},{"name":"ConfidenceDot","sourcePath":"components/data/ConfidenceDot.jsx"},{"name":"ConfidencePill","sourcePath":"components/data/ConfidencePill.jsx"},{"name":"FieldRow","sourcePath":"components/data/FieldRow.jsx"},{"name":"SourceList","sourcePath":"components/data/SourceList.jsx"},{"name":"StrengthMeter","sourcePath":"components/data/StrengthMeter.jsx"},{"name":"Input","sourcePath":"components/forms/Input.jsx"},{"name":"SearchBar","sourcePath":"components/navigation/SearchBar.jsx"},{"name":"SidebarItem","sourcePath":"components/navigation/SidebarNav.jsx"},{"name":"SidebarNav","sourcePath":"components/navigation/SidebarNav.jsx"},{"name":"Tabs","sourcePath":"components/navigation/Tabs.jsx"}],"sourceHashes":{"components/core/Avatar.jsx":"9fafdad3efa9","components/core/Badge.jsx":"9d2692f55f9f","components/core/Button.jsx":"903718488218","components/core/Card.jsx":"9bddca7a2fc3","components/core/Chip.jsx":"58a837aac7f6","components/core/IconButton.jsx":"f06fb40980a6","components/core/ProductMark.jsx":"e9d315fedc83","components/data/ConfidenceDot.jsx":"a8ae9866df17","components/data/ConfidencePill.jsx":"c7acd8b4a6ae","components/data/FieldRow.jsx":"7a7a1264862c","components/data/SourceList.jsx":"d44f562eb0d3","components/data/StrengthMeter.jsx":"f429859b3d69","components/forms/Input.jsx":"d6af9d8cbfd5","components/navigation/SearchBar.jsx":"f15eda08c0de","components/navigation/SidebarNav.jsx":"07d0568d4cde","components/navigation/Tabs.jsx":"0d212b6d81b0","ui_kits/kindle/AppShell.jsx":"059d573552db","ui_kits/kindle/AuthScreen.jsx":"3b3f3840c6f7","ui_kits/kindle/ContactView.jsx":"14ce41a7b139","ui_kits/kindle/PeopleList.jsx":"89d050491895","ui_kits/kindle/app.jsx":"ca9813889bc4","ui_kits/kindle/icons.jsx":"8b7b3025b30d"},"inlinedExternals":[],"unexposedExports":[]} */

(() => {

const __ds_ns = (window.DaykoDesignSystem_0082b9 = window.DaykoDesignSystem_0082b9 || {});

const __ds_scope = {};

(__ds_ns.__errors = __ds_ns.__errors || []);

// components/core/Avatar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const sizes = {
  xs: 24,
  sm: 32,
  md: 44,
  lg: 64,
  xl: 88
};
const accents = ["var(--avatar-1)", "var(--avatar-2)", "var(--avatar-3)", "var(--avatar-4)", "var(--purple-500)"];
function initials(name = "") {
  return name.trim().split(/\s+/).slice(0, 2).map(w => w[0] || "").join("").toUpperCase();
}

/** Circular person/company avatar. Shows a photo when `src` is given, otherwise
 *  initials on a deterministic warm accent. `ring` adds a status ring. */
function Avatar({
  name = "",
  src,
  size = "md",
  index = 0,
  ring,
  style,
  ...rest
}) {
  const px = typeof size === "number" ? size : sizes[size] || sizes.md;
  const bg = accents[index % accents.length];
  const fontSize = Math.round(px * 0.38);
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      position: "relative",
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: px,
      height: px,
      borderRadius: "50%",
      flex: "0 0 auto",
      background: src ? "var(--ink-100)" : bg,
      color: "#fff",
      fontFamily: "var(--font-sans)",
      fontWeight: "var(--fw-semibold)",
      fontSize,
      overflow: "hidden",
      userSelect: "none",
      boxShadow: ring ? `0 0 0 2px var(--surface-card), 0 0 0 4px ${ring}` : "none",
      ...style
    }
  }, rest), src ? /*#__PURE__*/React.createElement("img", {
    src: src,
    alt: name,
    style: {
      width: "100%",
      height: "100%",
      objectFit: "cover"
    }
  }) : initials(name));
}
Object.assign(__ds_scope, { Avatar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Avatar.jsx", error: String((e && e.message) || e) }); }

// components/core/Badge.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const tones = {
  neutral: {
    fg: "var(--ink-600)",
    bg: "var(--ink-100)"
  },
  success: {
    fg: "var(--status-success-fg)",
    bg: "var(--status-success-bg)"
  },
  warning: {
    fg: "var(--status-warning-fg)",
    bg: "var(--status-warning-bg)"
  },
  danger: {
    fg: "var(--status-danger-fg)",
    bg: "var(--status-danger-bg)"
  },
  info: {
    fg: "var(--status-info-fg)",
    bg: "var(--status-info-bg)"
  },
  accent: {
    fg: "var(--status-accent-fg)",
    bg: "var(--status-accent-bg)"
  },
  brand: {
    fg: "var(--coral-700)",
    bg: "var(--coral-50)"
  }
};

/** Small status pill. `dot` prepends a colored dot (relationship / active
 *  states); use tone to signal semantics. Fully rounded. */
function Badge({
  children,
  tone = "neutral",
  dot = false,
  style,
  ...rest
}) {
  const t = tones[tone] || tones.neutral;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      height: "22px",
      padding: "0 10px",
      borderRadius: "var(--radius-pill)",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-xs)",
      fontWeight: "var(--fw-semibold)",
      lineHeight: 1,
      whiteSpace: "nowrap",
      color: t.fg,
      background: t.bg,
      ...style
    }
  }, rest), dot && /*#__PURE__*/React.createElement("span", {
    style: {
      width: 7,
      height: 7,
      borderRadius: "50%",
      background: t.fg
    }
  }), children);
}
Object.assign(__ds_scope, { Badge });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Badge.jsx", error: String((e && e.message) || e) }); }

// components/core/Button.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const sizes = {
  sm: {
    height: "var(--control-sm)",
    padding: "0 12px",
    fontSize: "var(--text-sm)",
    gap: "6px"
  },
  md: {
    height: "var(--control-md)",
    padding: "0 16px",
    fontSize: "var(--text-base)",
    gap: "7px"
  },
  lg: {
    height: "var(--control-lg)",
    padding: "0 22px",
    fontSize: "var(--text-md)",
    gap: "8px"
  }
};
const variants = {
  primary: {
    background: "var(--action-primary-bg)",
    color: "var(--action-primary-fg)",
    border: "1px solid transparent"
  },
  dark: {
    background: "var(--action-dark-bg)",
    color: "var(--action-dark-fg)",
    border: "1px solid transparent"
  },
  secondary: {
    background: "var(--surface-card)",
    color: "var(--text-primary)",
    border: "1px solid var(--border-subtle)"
  },
  ghost: {
    background: "transparent",
    color: "var(--action-ghost-fg)",
    border: "1px solid transparent"
  }
};
const hovers = {
  primary: "var(--action-primary-bg-hover)",
  dark: "var(--action-dark-bg-hover)",
  secondary: "var(--surface-hover)",
  ghost: "var(--action-ghost-bg-hover)"
};

/** Primary action control. Coral by default; `dark` for the highest-emphasis
 *  AI action ("Run Intelligence"); `secondary` outline; `ghost` text button. */
function Button({
  children,
  variant = "primary",
  size = "md",
  iconLeft,
  iconRight,
  fullWidth = false,
  disabled = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const v = variants[variant] || variants.primary;
  const s = sizes[size] || sizes.md;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      fontFamily: "var(--font-sans)",
      fontWeight: "var(--fw-semibold)",
      lineHeight: 1,
      letterSpacing: "-0.01em",
      borderRadius: "var(--radius-md)",
      cursor: disabled ? "not-allowed" : "pointer",
      width: fullWidth ? "100%" : "auto",
      opacity: disabled ? 0.5 : 1,
      transition: "background 150ms ease, box-shadow 150ms ease, color 150ms ease",
      ...s,
      ...v,
      background: hover && !disabled ? hovers[variant] : v.background,
      ...style
    }
  }, rest), iconLeft && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      marginLeft: "-2px"
    }
  }, iconLeft), children, iconRight && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      marginRight: "-2px"
    }
  }, iconRight));
}
Object.assign(__ds_scope, { Button });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Button.jsx", error: String((e && e.message) || e) }); }

// components/core/Card.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** The signature Dayko surface: white, hairline border, soft shadow, 14px
 *  radius. Compose `CardHeader` / `CardBody` / `CardFooter`, or drop children
 *  straight in. `pad` toggles default body padding. */
function Card({
  children,
  pad = true,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      background: "var(--surface-card)",
      border: "1px solid var(--border-subtle)",
      borderRadius: "var(--radius-lg)",
      boxShadow: "var(--shadow-sm)",
      overflow: "hidden",
      ...style
    }
  }, rest), pad ? /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "var(--space-5)"
    }
  }, children) : children);
}

/** Card header row: title (with optional icon) on the left, actions on the right. */
function CardHeader({
  title,
  icon,
  action,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      padding: "14px var(--space-5)",
      borderBottom: "1px solid var(--border-subtle)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "10px"
    }
  }, icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      color: "var(--ink-500)"
    }
  }, icon), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontWeight: "var(--fw-semibold)",
      fontSize: "var(--text-md)",
      color: "var(--text-primary)"
    }
  }, title)), action);
}
function CardBody({
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      padding: "var(--space-3) var(--space-5)",
      ...style
    }
  }, rest), children);
}

/** Sunken footer strip — used for the "SOURCES" chip row. */
function CardFooter({
  children,
  label,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      flexWrap: "wrap",
      padding: "12px var(--space-5)",
      background: "var(--surface-sunken)",
      borderTop: "1px solid var(--border-subtle)",
      ...style
    }
  }, rest), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontSize: "var(--text-2xs)",
      fontWeight: "var(--fw-semibold)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--text-tertiary)",
      marginRight: 2
    }
  }, label), children);
}
Object.assign(__ds_scope, { Card, CardHeader, CardBody, CardFooter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Card.jsx", error: String((e && e.message) || e) }); }

// components/core/Chip.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Outlined pill used for filters, focus areas, and source citations. Optional
 *  leading icon (e.g. a link icon on "SOURCES" chips). Interactive when onClick. */
function Chip({
  children,
  icon,
  active = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const interactive = !!onClick;
  return /*#__PURE__*/React.createElement("span", _extends({
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      height: "28px",
      padding: "0 12px",
      borderRadius: "var(--radius-pill)",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-sm)",
      fontWeight: "var(--fw-medium)",
      lineHeight: 1,
      whiteSpace: "nowrap",
      cursor: interactive ? "pointer" : "default",
      color: active ? "var(--coral-700)" : "var(--ink-700)",
      background: active ? "var(--coral-50)" : hover && interactive ? "var(--surface-hover)" : "var(--surface-card)",
      border: `1px solid ${active ? "var(--coral-200)" : "var(--border-subtle)"}`,
      transition: "background 150ms ease, border-color 150ms ease",
      ...style
    }
  }, rest), icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      color: "var(--ink-400)"
    }
  }, icon), children);
}
Object.assign(__ds_scope, { Chip });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/Chip.jsx", error: String((e && e.message) || e) }); }

// components/core/IconButton.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const sizes = {
  sm: 30,
  md: 36,
  lg: 44
};
const variants = {
  ghost: {
    background: "transparent",
    color: "var(--ink-600)",
    border: "1px solid transparent"
  },
  outline: {
    background: "var(--surface-card)",
    color: "var(--ink-700)",
    border: "1px solid var(--border-subtle)"
  },
  dark: {
    background: "var(--ink-900)",
    color: "#fff",
    border: "1px solid transparent"
  }
};
const hovers = {
  ghost: "var(--action-ghost-bg-hover)",
  outline: "var(--surface-hover)",
  dark: "var(--action-dark-bg-hover)"
};

/** Square icon-only button. Used for toolbar / row actions (more, add, close). */
function IconButton({
  icon,
  variant = "ghost",
  size = "md",
  label,
  disabled,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  const px = sizes[size] || sizes.md;
  const v = variants[variant] || variants.ghost;
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    "aria-label": label,
    disabled: disabled,
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: px,
      height: px,
      borderRadius: "var(--radius-md)",
      cursor: disabled ? "not-allowed" : "pointer",
      opacity: disabled ? 0.45 : 1,
      transition: "background 150ms ease",
      ...v,
      background: hover && !disabled ? hovers[variant] : v.background,
      ...style
    }
  }, rest), icon);
}
Object.assign(__ds_scope, { IconButton });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/IconButton.jsx", error: String((e && e.message) || e) }); }

// components/core/ProductMark.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const sizes = {
  sm: 28,
  md: 36,
  lg: 48
};

/** The K/E/P product tile — a rounded-square coral avatar holding a product's
 *  initial (or a custom glyph). Dayko renders its apps as letter tiles, not
 *  bespoke logos. */
function ProductMark({
  letter = "K",
  glyph,
  size = "md",
  tone = "coral",
  style,
  ...rest
}) {
  const px = typeof size === "number" ? size : sizes[size] || sizes.md;
  const bg = tone === "dark" ? "var(--ink-900)" : "var(--coral-500)";
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      justifyContent: "center",
      width: px,
      height: px,
      borderRadius: Math.round(px * 0.28),
      background: bg,
      color: "#fff",
      flex: "0 0 auto",
      fontFamily: "var(--font-display)",
      fontWeight: "var(--fw-bold)",
      fontSize: Math.round(px * 0.5),
      lineHeight: 1,
      userSelect: "none",
      boxShadow: "var(--shadow-xs)",
      ...style
    }
  }, rest), glyph || letter);
}
Object.assign(__ds_scope, { ProductMark });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/core/ProductMark.jsx", error: String((e && e.message) || e) }); }

// components/data/ConfidenceDot.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const colors = {
  high: "var(--green-500)",
  medium: "var(--amber-500)",
  low: "var(--red-500)",
  none: "var(--ink-300)"
};

/** The trailing confidence dot on intelligence field rows.
 *  high (green ≥90%) · medium (amber 75–89%) · low (red <75%). */
function ConfidenceDot({
  level = "high",
  size = 8,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    title: level,
    style: {
      display: "inline-block",
      width: size,
      height: size,
      borderRadius: "50%",
      background: colors[level] || colors.none,
      flex: "0 0 auto",
      ...style
    }
  }, rest));
}
Object.assign(__ds_scope, { ConfidenceDot });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ConfidenceDot.jsx", error: String((e && e.message) || e) }); }

// components/data/ConfidencePill.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const tones = {
  high: {
    fg: "var(--green-500)",
    bg: "var(--green-soft)"
  },
  medium: {
    fg: "var(--amber-500)",
    bg: "var(--amber-soft)"
  },
  low: {
    fg: "var(--red-500)",
    bg: "var(--red-soft)"
  }
};

/** Confidence pill in a card header: colored dot + label on a soft tint.
 *  e.g. "88% confidence" (medium/amber), "91% confidence" (high/green). */
function ConfidencePill({
  level = "high",
  children,
  style,
  ...rest
}) {
  const t = tones[level] || tones.high;
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      height: "24px",
      padding: "0 10px",
      borderRadius: "var(--radius-pill)",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-xs)",
      fontWeight: "var(--fw-semibold)",
      lineHeight: 1,
      whiteSpace: "nowrap",
      color: t.fg,
      background: t.bg,
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement(__ds_scope.ConfidenceDot, {
    level: level,
    size: 7
  }), children);
}
Object.assign(__ds_scope, { ConfidencePill });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/ConfidencePill.jsx", error: String((e && e.message) || e) }); }

// components/data/FieldRow.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** A label/value row inside an intelligence card. Label left (muted), value
 *  right (primary), optional trailing confidence dot. `emphasis` colors the
 *  value (e.g. green net-worth, coral pledge). */
function FieldRow({
  label,
  value,
  confidence,
  emphasis = "default",
  href,
  style,
  ...rest
}) {
  const valueColor = {
    default: "var(--text-primary)",
    brand: "var(--coral-600)",
    success: "var(--green-500)",
    muted: "var(--text-secondary)"
  }[emphasis] || "var(--text-primary)";
  const Value = href ? "a" : "span";
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      justifyContent: "space-between",
      gap: "16px",
      padding: "11px 0",
      borderBottom: "1px solid var(--border-subtle)",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-base)",
      color: "var(--text-secondary)",
      flex: "0 0 auto"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "10px",
      minWidth: 0,
      textAlign: "right"
    }
  }, /*#__PURE__*/React.createElement(Value, {
    href: href,
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-base)",
      fontWeight: "var(--fw-semibold)",
      color: valueColor,
      overflow: "hidden",
      textOverflow: "ellipsis",
      whiteSpace: "nowrap"
    }
  }, value), confidence && /*#__PURE__*/React.createElement(__ds_scope.ConfidenceDot, {
    level: confidence
  })));
}
Object.assign(__ds_scope, { FieldRow });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/FieldRow.jsx", error: String((e && e.message) || e) }); }

// components/data/SourceList.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const LinkIcon = () => /*#__PURE__*/React.createElement("svg", {
  width: "13",
  height: "13",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "1.9",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, /*#__PURE__*/React.createElement("path", {
  d: "M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71"
}), /*#__PURE__*/React.createElement("path", {
  d: "M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"
}));

/** The card-footer "SOURCES" row: an uppercase label with a link glyph followed
 *  by outlined source chips. */
function SourceList({
  sources = [],
  label = "Sources",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      gap: "8px",
      flexWrap: "wrap",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "6px",
      fontSize: "var(--text-2xs)",
      fontWeight: "var(--fw-semibold)",
      letterSpacing: "var(--tracking-caps)",
      textTransform: "uppercase",
      color: "var(--text-tertiary)"
    }
  }, /*#__PURE__*/React.createElement(LinkIcon, null), label), sources.map((s, i) => /*#__PURE__*/React.createElement(__ds_scope.Chip, {
    key: i
  }, s)));
}
Object.assign(__ds_scope, { SourceList });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/SourceList.jsx", error: String((e && e.message) || e) }); }

// components/data/StrengthMeter.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Segmented relationship-strength meter (the coral bars on contact headers).
 *  `value` of `max` segments filled; trailing label. */
function StrengthMeter({
  value = 4,
  max = 5,
  label,
  color = "var(--coral-500)",
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("span", _extends({
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: "10px",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      gap: "3px"
    }
  }, Array.from({
    length: max
  }).map((_, i) => /*#__PURE__*/React.createElement("span", {
    key: i,
    style: {
      width: 5,
      height: 18,
      borderRadius: 2,
      background: i < value ? color : "var(--ink-200)"
    }
  }))), label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-base)",
      fontWeight: "var(--fw-semibold)",
      color: "var(--text-primary)"
    }
  }, label));
}
Object.assign(__ds_scope, { StrengthMeter });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/data/StrengthMeter.jsx", error: String((e && e.message) || e) }); }

// components/forms/Input.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Text input with optional label and leading icon. Coral focus ring, hairline
 *  border, 10px radius — matches the auth-screen email field. */
function Input({
  label,
  icon,
  type = "text",
  placeholder,
  value,
  onChange,
  disabled,
  error,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("label", {
    style: {
      display: "flex",
      flexDirection: "column",
      gap: "7px",
      width: "100%",
      ...style
    }
  }, label && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-sm)",
      fontWeight: "var(--fw-semibold)",
      color: "var(--text-primary)"
    }
  }, label), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: "9px",
      height: "var(--control-lg)",
      padding: "0 14px",
      borderRadius: "var(--radius-md)",
      background: disabled ? "var(--surface-sunken)" : "var(--surface-card)",
      border: `1px solid ${error ? "var(--red-500)" : focus ? "var(--coral-400)" : "var(--border-subtle)"}`,
      boxShadow: focus && !error ? "var(--ring-brand)" : "none",
      transition: "box-shadow 150ms ease, border-color 150ms ease"
    }
  }, icon && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      color: "var(--ink-400)"
    }
  }, icon), /*#__PURE__*/React.createElement("input", _extends({
    type: type,
    placeholder: placeholder,
    value: value,
    onChange: onChange,
    disabled: disabled,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      border: "none",
      outline: "none",
      background: "transparent",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-base)",
      color: "var(--text-primary)"
    }
  }, rest))), error && typeof error === "string" && /*#__PURE__*/React.createElement("span", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-xs)",
      color: "var(--red-500)"
    }
  }, error));
}
Object.assign(__ds_scope, { Input });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/forms/Input.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SearchBar.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
const SearchIcon = () => /*#__PURE__*/React.createElement("svg", {
  width: "17",
  height: "17",
  viewBox: "0 0 24 24",
  fill: "none",
  stroke: "currentColor",
  strokeWidth: "1.9",
  strokeLinecap: "round",
  strokeLinejoin: "round"
}, /*#__PURE__*/React.createElement("circle", {
  cx: "11",
  cy: "11",
  r: "7"
}), /*#__PURE__*/React.createElement("path", {
  d: "m21 21-4.3-4.3"
}));

/** The centered top-bar search field with a leading icon and a ⌘K hint. */
function SearchBar({
  placeholder = "Search anything…",
  shortcut = "⌘K",
  value,
  onChange,
  style,
  ...rest
}) {
  const [focus, setFocus] = React.useState(false);
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      gap: "10px",
      width: "100%",
      maxWidth: 420,
      height: "var(--control-md)",
      padding: "0 12px",
      borderRadius: "var(--radius-pill)",
      background: "var(--surface-card)",
      border: `1px solid ${focus ? "var(--coral-300)" : "var(--border-subtle)"}`,
      boxShadow: focus ? "var(--ring-brand)" : "none",
      transition: "box-shadow 150ms ease, border-color 150ms ease",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      color: "var(--ink-400)"
    }
  }, /*#__PURE__*/React.createElement(SearchIcon, null)), /*#__PURE__*/React.createElement("input", {
    value: value,
    onChange: onChange,
    placeholder: placeholder,
    onFocus: () => setFocus(true),
    onBlur: () => setFocus(false),
    style: {
      flex: 1,
      minWidth: 0,
      border: "none",
      outline: "none",
      background: "transparent",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-base)",
      color: "var(--text-primary)"
    }
  }), shortcut && /*#__PURE__*/React.createElement("kbd", {
    style: {
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-xs)",
      color: "var(--ink-400)",
      background: "var(--ink-100)",
      borderRadius: 6,
      padding: "2px 6px"
    }
  }, shortcut));
}
Object.assign(__ds_scope, { SearchBar });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SearchBar.jsx", error: String((e && e.message) || e) }); }

// components/navigation/SidebarNav.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** A single sidebar navigation row: line icon + label, coral-tint active state,
 *  neutral hover wash. Compose several inside a <nav>. */
function SidebarItem({
  icon,
  label,
  active = false,
  onClick,
  style,
  ...rest
}) {
  const [hover, setHover] = React.useState(false);
  return /*#__PURE__*/React.createElement("button", _extends({
    type: "button",
    onClick: onClick,
    onMouseEnter: () => setHover(true),
    onMouseLeave: () => setHover(false),
    style: {
      display: "flex",
      alignItems: "center",
      gap: "11px",
      width: "100%",
      height: "38px",
      padding: "0 12px",
      borderRadius: "var(--radius-md)",
      border: "none",
      cursor: "pointer",
      textAlign: "left",
      fontFamily: "var(--font-sans)",
      fontSize: "var(--text-base)",
      fontWeight: active ? "var(--fw-semibold)" : "var(--fw-medium)",
      color: active ? "var(--coral-700)" : "var(--ink-700)",
      background: active ? "var(--coral-50)" : hover ? "var(--surface-hover)" : "transparent",
      transition: "background 130ms ease",
      ...style
    }
  }, rest), /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      color: active ? "var(--coral-600)" : "var(--ink-500)"
    }
  }, icon), label);
}

/** Product sidebar shell: a ProductMark + name header, then nav items. */
function SidebarNav({
  header,
  children,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("nav", _extends({
    style: {
      width: "var(--sidebar-w)",
      display: "flex",
      flexDirection: "column",
      gap: "2px",
      padding: "16px 12px",
      background: "var(--surface-card)",
      borderRight: "1px solid var(--border-subtle)",
      ...style
    }
  }, rest), header && /*#__PURE__*/React.createElement("div", {
    style: {
      padding: "4px 8px 14px"
    }
  }, header), children);
}
Object.assign(__ds_scope, { SidebarItem, SidebarNav });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/SidebarNav.jsx", error: String((e && e.message) || e) }); }

// components/navigation/Tabs.jsx
try { (() => {
function _extends() { return _extends = Object.assign ? Object.assign.bind() : function (n) { for (var e = 1; e < arguments.length; e++) { var t = arguments[e]; for (var r in t) ({}).hasOwnProperty.call(t, r) && (n[r] = t[r]); } return n; }, _extends.apply(null, arguments); }
/** Underline tab bar (Overview / Network / Profile / Intelligence …).
 *  Controlled via `value`/`onChange`. */
function Tabs({
  tabs = [],
  value,
  onChange,
  style,
  ...rest
}) {
  return /*#__PURE__*/React.createElement("div", _extends({
    style: {
      display: "flex",
      alignItems: "center",
      gap: "24px",
      borderBottom: "1px solid var(--border-subtle)",
      ...style
    }
  }, rest), tabs.map(t => {
    const key = typeof t === "string" ? t : t.value;
    const label = typeof t === "string" ? t : t.label;
    const active = key === value;
    return /*#__PURE__*/React.createElement("button", {
      key: key,
      type: "button",
      onClick: () => onChange && onChange(key),
      style: {
        position: "relative",
        border: "none",
        background: "none",
        cursor: "pointer",
        padding: "12px 0",
        fontFamily: "var(--font-sans)",
        fontSize: "var(--text-base)",
        fontWeight: active ? "var(--fw-semibold)" : "var(--fw-medium)",
        color: active ? "var(--text-primary)" : "var(--text-secondary)",
        transition: "color 130ms ease"
      }
    }, label, active && /*#__PURE__*/React.createElement("span", {
      style: {
        position: "absolute",
        left: 0,
        right: 0,
        bottom: -1,
        height: 2,
        background: "var(--coral-500)",
        borderRadius: 2
      }
    }));
  }));
}
Object.assign(__ds_scope, { Tabs });
})(); } catch (e) { __ds_ns.__errors.push({ path: "components/navigation/Tabs.jsx", error: String((e && e.message) || e) }); }

// ui_kits/kindle/AppShell.jsx
try { (() => {
// Kindle app chrome: far-left icon rail + product sidebar + top bar.
(function () {
  const NS = window.DaykoDesignSystem_0082b9;
  const {
    SidebarNav,
    SidebarItem,
    SearchBar,
    ProductMark,
    Button,
    IconButton,
    Avatar
  } = NS;
  const I = window.KIcons;
  function Rail({
    onLogo
  }) {
    const items = [I.Home, I.Copy, I.Message];
    return /*#__PURE__*/React.createElement("div", {
      style: {
        width: "var(--rail-w)",
        background: "var(--ink-900)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "12px 0",
        gap: 4,
        flex: "0 0 auto"
      }
    }, /*#__PURE__*/React.createElement("button", {
      onClick: onLogo,
      title: "Dayko",
      style: {
        border: "none",
        background: "none",
        cursor: "pointer",
        padding: 0,
        marginBottom: 8
      }
    }, /*#__PURE__*/React.createElement("img", {
      src: "../../assets/dayko-mark.png",
      style: {
        width: 30,
        height: 30,
        display: "block"
      }
    })), items.map((Ic, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        width: 38,
        height: 38,
        borderRadius: 10,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "rgba(255,255,255,.55)",
        cursor: "pointer"
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      size: 19
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        width: 34,
        height: 34,
        borderRadius: 9,
        background: "var(--ink-700)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "rgba(255,255,255,.8)",
        fontSize: 13,
        fontWeight: 600,
        marginTop: 2
      }
    }, "M"), /*#__PURE__*/React.createElement("div", {
      style: {
        width: 40,
        height: 40,
        borderRadius: 11,
        background: "var(--coral-500)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "#fff",
        marginTop: 2
      }
    }, /*#__PURE__*/React.createElement(I.Zap, {
      size: 20
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }), [I.Store, I.Zap, I.Users, I.Settings, I.Help].map((Ic, i) => /*#__PURE__*/React.createElement("div", {
      key: i,
      style: {
        width: 38,
        height: 38,
        borderRadius: 10,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "rgba(255,255,255,.4)",
        cursor: "pointer"
      }
    }, /*#__PURE__*/React.createElement(Ic, {
      size: 18
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        width: 30,
        height: 30,
        borderRadius: "50%",
        background: "var(--ink-700)",
        marginTop: 6
      }
    }));
  }
  function AppShell({
    nav = "People",
    breadcrumb,
    onNav,
    search = "Search anything….",
    children
  }) {
    const I = window.KIcons;
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        height: "100%",
        background: "var(--surface-page)",
        fontFamily: "var(--font-sans)",
        color: "var(--text-primary)"
      }
    }, /*#__PURE__*/React.createElement(Rail, {
      onLogo: () => onNav && onNav("People")
    }), /*#__PURE__*/React.createElement(SidebarNav, {
      header: /*#__PURE__*/React.createElement("div", {
        style: {
          display: "flex",
          gap: 9,
          alignItems: "center",
          padding: "2px 2px 0"
        }
      }, /*#__PURE__*/React.createElement(ProductMark, {
        glyph: /*#__PURE__*/React.createElement(I.Zap, {
          size: 18
        }),
        size: "sm"
      }), /*#__PURE__*/React.createElement("span", {
        style: {
          fontFamily: "var(--font-display)",
          fontWeight: 700,
          fontSize: 18
        }
      }, "Kindle"))
    }, /*#__PURE__*/React.createElement(SidebarItem, {
      icon: /*#__PURE__*/React.createElement(I.Home, {
        size: 17
      }),
      label: "Home",
      active: nav === "Home",
      onClick: () => onNav && onNav("Home")
    }), /*#__PURE__*/React.createElement(SidebarItem, {
      icon: /*#__PURE__*/React.createElement(I.Users, {
        size: 17
      }),
      label: "People",
      active: nav === "People",
      onClick: () => onNav && onNav("People")
    }), /*#__PURE__*/React.createElement(SidebarItem, {
      icon: /*#__PURE__*/React.createElement(I.Building, {
        size: 17
      }),
      label: "Company",
      active: nav === "Company",
      onClick: () => onNav && onNav("Company")
    }), /*#__PURE__*/React.createElement(SidebarItem, {
      icon: /*#__PURE__*/React.createElement(I.Calendar, {
        size: 17
      }),
      label: "Meetings",
      active: nav === "Meetings",
      onClick: () => onNav && onNav("Meetings")
    }), /*#__PURE__*/React.createElement(SidebarItem, {
      icon: /*#__PURE__*/React.createElement(I.Message, {
        size: 17
      }),
      label: "Interactions",
      active: nav === "Interactions",
      onClick: () => onNav && onNav("Interactions")
    }), /*#__PURE__*/React.createElement(SidebarItem, {
      icon: /*#__PURE__*/React.createElement(I.Users, {
        size: 17
      }),
      label: "Teams",
      active: nav === "Teams",
      onClick: () => onNav && onNav("Teams")
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0,
        display: "flex",
        flexDirection: "column"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        height: "var(--topbar-h)",
        flex: "0 0 auto",
        display: "flex",
        alignItems: "center",
        gap: 14,
        padding: "0 18px",
        borderBottom: "1px solid var(--border-subtle)",
        background: "var(--surface-card)"
      }
    }, /*#__PURE__*/React.createElement(IconButton, {
      icon: /*#__PURE__*/React.createElement(I.Sidebar, {
        size: 18
      }),
      label: "Toggle sidebar"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 7,
        color: "var(--text-secondary)",
        fontSize: 14,
        fontWeight: 500
      }
    }, breadcrumb), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        display: "flex",
        justifyContent: "center"
      }
    }, /*#__PURE__*/React.createElement(SearchBar, {
      placeholder: search
    })), /*#__PURE__*/React.createElement(Button, {
      iconLeft: /*#__PURE__*/React.createElement(I.Plus, {
        size: 16
      })
    }, "Create")), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minHeight: 0,
        overflow: "auto"
      }
    }, children)));
  }
  window.KAppShell = AppShell;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/kindle/AppShell.jsx", error: String((e && e.message) || e) }); }

// ui_kits/kindle/AuthScreen.jsx
try { (() => {
// Kindle / Dayko auth — the "Get Started" screen.
(function () {
  const NS = window.DaykoDesignSystem_0082b9;
  const {
    Button,
    Input
  } = NS;
  const I = window.KIcons;
  const GoogleG = () => /*#__PURE__*/React.createElement("svg", {
    width: "18",
    height: "18",
    viewBox: "0 0 48 48"
  }, /*#__PURE__*/React.createElement("path", {
    fill: "#EA4335",
    d: "M24 9.5c3.5 0 6.6 1.2 9 3.6l6.7-6.7C35.6 2.4 30.1 0 24 0 14.6 0 6.5 5.4 2.6 13.3l7.8 6c1.9-5.6 7.1-9.8 13.6-9.8Z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#4285F4",
    d: "M46.1 24.5c0-1.6-.1-3.1-.4-4.5H24v9h12.4c-.5 2.9-2.2 5.3-4.6 7l7.1 5.5c4.2-3.9 6.6-9.6 6.6-16.5Z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#FBBC05",
    d: "M10.4 28.7a14.5 14.5 0 0 1 0-9.3l-7.8-6a24 24 0 0 0 0 21.3l7.8-6Z"
  }), /*#__PURE__*/React.createElement("path", {
    fill: "#34A853",
    d: "M24 48c6.1 0 11.3-2 15-5.5l-7.1-5.5c-2 1.4-4.6 2.2-7.9 2.2-6.5 0-11.7-4.2-13.6-9.8l-7.8 6C6.5 42.6 14.6 48 24 48Z"
  }));
  const MsSquares = () => /*#__PURE__*/React.createElement("svg", {
    width: "16",
    height: "16",
    viewBox: "0 0 24 24"
  }, /*#__PURE__*/React.createElement("rect", {
    x: "1",
    y: "1",
    width: "10",
    height: "10",
    fill: "#F25022"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "13",
    y: "1",
    width: "10",
    height: "10",
    fill: "#7FBA00"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "1",
    y: "13",
    width: "10",
    height: "10",
    fill: "#00A4EF"
  }), /*#__PURE__*/React.createElement("rect", {
    x: "13",
    y: "13",
    width: "10",
    height: "10",
    fill: "#FFB900"
  }));
  function AuthScreen({
    onContinue
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        minHeight: "100%",
        background: "var(--surface-page)",
        fontFamily: "var(--font-sans)",
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        padding: "72px 20px"
      }
    }, /*#__PURE__*/React.createElement("img", {
      src: "../../assets/dayko-logo-dark.png",
      style: {
        height: 40,
        marginBottom: 44
      }
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        width: 520,
        maxWidth: "100%",
        background: "var(--surface-card)",
        border: "1px solid var(--border-subtle)",
        borderRadius: "var(--radius-2xl)",
        boxShadow: "var(--shadow-md)",
        padding: "36px 40px"
      }
    }, /*#__PURE__*/React.createElement("h1", {
      style: {
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        fontSize: 26,
        letterSpacing: "-0.02em",
        margin: "0 0 6px"
      }
    }, "Get Started"), /*#__PURE__*/React.createElement("p", {
      style: {
        color: "var(--text-secondary)",
        fontSize: 14,
        margin: "0 0 26px"
      }
    }, "Sign in with your work account to continue."), /*#__PURE__*/React.createElement("button", {
      onClick: onContinue,
      style: ssoStyle
    }, /*#__PURE__*/React.createElement(GoogleG, null), " Continue with Google"), /*#__PURE__*/React.createElement("div", {
      style: {
        height: 12
      }
    }), /*#__PURE__*/React.createElement("button", {
      onClick: onContinue,
      style: ssoStyle
    }, /*#__PURE__*/React.createElement(MsSquares, null), " Continue with Microsoft"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 14,
        margin: "22px 0",
        color: "var(--text-tertiary)",
        fontSize: 12
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        height: 1,
        background: "var(--border-subtle)"
      }
    }), " or continue with ", /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        height: 1,
        background: "var(--border-subtle)"
      }
    })), /*#__PURE__*/React.createElement(Input, {
      label: "Email",
      type: "email",
      placeholder: "my@company.com"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        height: 18
      }
    }), /*#__PURE__*/React.createElement(Button, {
      fullWidth: true,
      size: "lg",
      iconLeft: /*#__PURE__*/React.createElement(I.Sparkles, {
        size: 17
      }),
      onClick: onContinue
    }, "Send Magic Code")), /*#__PURE__*/React.createElement("p", {
      style: {
        color: "var(--text-tertiary)",
        fontSize: 12.5,
        textAlign: "center",
        maxWidth: 420,
        marginTop: 26,
        lineHeight: 1.5
      }
    }, "By proceeding you acknowledge that you have read, understood and agree to our ", /*#__PURE__*/React.createElement("a", {
      href: "#"
    }, "Terms and Conditions.")), /*#__PURE__*/React.createElement("p", {
      style: {
        color: "var(--text-tertiary)",
        fontSize: 12,
        marginTop: 4
      }
    }, "\xA92026 Dayko.ai"));
  }
  const ssoStyle = {
    display: "flex",
    alignItems: "center",
    justifyContent: "center",
    gap: 10,
    width: "100%",
    height: 48,
    borderRadius: "var(--radius-md)",
    border: "1px solid var(--border-subtle)",
    background: "var(--surface-card)",
    cursor: "pointer",
    fontFamily: "var(--font-sans)",
    fontSize: 14,
    fontWeight: 600,
    color: "var(--text-primary)"
  };
  window.KAuthScreen = AuthScreen;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/kindle/AuthScreen.jsx", error: String((e && e.message) || e) }); }

// ui_kits/kindle/ContactView.jsx
try { (() => {
// Kindle — contact record: header, stat strip, tabs, AI intelligence grid.
(function () {
  const NS = window.DaykoDesignSystem_0082b9;
  const {
    Avatar,
    Badge,
    Chip,
    Button,
    IconButton,
    Tabs,
    StrengthMeter,
    Card,
    CardHeader,
    CardBody,
    CardFooter,
    FieldRow,
    ConfidencePill,
    SourceList,
    ProductMark
  } = NS;
  const I = window.KIcons;
  const StatCell = ({
    label,
    ai,
    children
  }) => /*#__PURE__*/React.createElement("div", {
    style: {
      flex: 1,
      minWidth: 0,
      padding: "0 22px",
      borderLeft: "1px solid var(--border-subtle)"
    }
  }, /*#__PURE__*/React.createElement("div", {
    style: {
      display: "flex",
      alignItems: "center",
      gap: 6,
      fontSize: 11,
      fontWeight: 600,
      letterSpacing: "0.06em",
      textTransform: "uppercase",
      color: "var(--text-tertiary)",
      marginBottom: 9
    }
  }, label, ai && /*#__PURE__*/React.createElement("span", {
    style: {
      display: "inline-flex",
      alignItems: "center",
      gap: 3,
      color: "var(--coral-500)"
    }
  }, /*#__PURE__*/React.createElement(I.Sparkles, {
    size: 12
  }), "AI")), children);
  const contactChip = {
    display: "inline-flex",
    alignItems: "center",
    gap: 6,
    height: 30,
    padding: "0 12px",
    borderRadius: 999,
    border: "1px solid var(--border-subtle)",
    background: "var(--surface-card)",
    fontSize: 13,
    color: "var(--text-secondary)"
  };
  function Overview() {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        background: "var(--surface-card)",
        border: "1px solid var(--border-subtle)",
        borderRadius: "var(--radius-lg)",
        boxShadow: "var(--shadow-sm)",
        padding: 20,
        marginBottom: 18
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        flexWrap: "wrap",
        gap: 10
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(ProductMark, {
      glyph: /*#__PURE__*/React.createElement(I.Sparkles, {
        size: 18
      }),
      tone: "dark",
      size: "sm"
    }), /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 600,
        fontSize: 15
      }
    }, "AI-generated overview"), /*#__PURE__*/React.createElement("span", {
      style: {
        display: "flex",
        gap: 14,
        marginLeft: 8,
        fontSize: 12.5,
        color: "var(--text-secondary)"
      }
    }, /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", {
      style: {
        color: "var(--green-500)"
      }
    }, "\u25CF"), " High 90%+"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", {
      style: {
        color: "var(--amber-500)"
      }
    }, "\u25CF"), " High 75-89%"), /*#__PURE__*/React.createElement("span", null, /*#__PURE__*/React.createElement("b", {
      style: {
        color: "var(--red-500)"
      }
    }, "\u25CF"), " Low <75%"))), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 12.5,
        color: "var(--text-tertiary)"
      }
    }, "Generated by Kindle Intelligence using public sources. Verify before use.")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 12,
        marginTop: 16
      }
    }, /*#__PURE__*/React.createElement(I.Sparkles, {
      size: 16,
      style: {
        color: "var(--coral-500)",
        flex: "0 0 auto",
        marginTop: 3
      }
    }), /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("div", {
      style: {
        fontWeight: 600,
        fontSize: 13.5,
        marginBottom: 6
      }
    }, "AI Summary Overview"), /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontSize: 14,
        lineHeight: 1.55,
        color: "var(--text-primary)",
        maxWidth: 900
      }
    }, "Abdulla bin Ahmad Al Ghurair pledged one-third of his personal wealth, worth $1.1 billion (AED 4.2 billion), to establish the Abdulla Al Ghurair Foundation for Education in 2015, supporting education and career opportunities for Arab youth."), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 7,
        alignItems: "center",
        marginTop: 12,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement(Chip, {
      icon: /*#__PURE__*/React.createElement(I.Link, {
        size: 13
      })
    }, "cnn.in"), /*#__PURE__*/React.createElement(Chip, {
      icon: /*#__PURE__*/React.createElement(I.Link, {
        size: 13
      })
    }, "medium.com"), /*#__PURE__*/React.createElement(Chip, {
      icon: /*#__PURE__*/React.createElement(I.Link, {
        size: 13
      })
    }, "banana.co.in"), /*#__PURE__*/React.createElement(Chip, null, "+4"), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--green-500)",
        fontSize: 13,
        fontWeight: 600,
        marginLeft: 4
      }
    }, "92% Confidence")))));
  }
  function IntelGrid() {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "grid",
        gridTemplateColumns: "1fr 1fr",
        gap: 18,
        alignItems: "start"
      }
    }, /*#__PURE__*/React.createElement(Card, {
      pad: false
    }, /*#__PURE__*/React.createElement(CardHeader, {
      icon: /*#__PURE__*/React.createElement(I.User, {
        size: 16
      }),
      title: "Personal Details",
      action: /*#__PURE__*/React.createElement(ConfidencePill, {
        level: "medium"
      }, "88% confidence")
    }), /*#__PURE__*/React.createElement(CardBody, null, /*#__PURE__*/React.createElement(FieldRow, {
      label: "Born",
      value: "c. 1929\u201330, Dubai",
      confidence: "low"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Nationality",
      value: "Emirati",
      confidence: "high"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Religion",
      value: "Islam",
      confidence: "high"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Marital status",
      value: "Married",
      confidence: "high"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Children",
      value: "4",
      confidence: "high"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Father",
      value: "Ahmad Al Ghurair \xB7 pearl trader",
      confidence: "medium"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Education",
      value: "Secondary, Kuwait",
      confidence: "medium",
      style: {
        borderBottom: "none"
      }
    })), /*#__PURE__*/React.createElement(CardFooter, null, /*#__PURE__*/React.createElement(SourceList, {
      sources: ["Forbes Profile", "Wikipedia", "Gulf News"]
    }))), /*#__PURE__*/React.createElement(Card, {
      pad: false
    }, /*#__PURE__*/React.createElement(CardHeader, {
      icon: /*#__PURE__*/React.createElement(I.Gem, {
        size: 16
      }),
      title: "Education Pledge",
      action: /*#__PURE__*/React.createElement(ConfidencePill, {
        level: "low"
      }, "72% confidence")
    }), /*#__PURE__*/React.createElement(CardBody, null, /*#__PURE__*/React.createElement(FieldRow, {
      label: "Forbes net worth",
      value: "$4.4B (May 2026)",
      emphasis: "success",
      confidence: "high"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Bloomberg estimate",
      value: "~$10.3B",
      confidence: "low"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Forbes world rank",
      value: "#954",
      confidence: "low"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Arab wealth rank",
      value: "#8 (2026)",
      confidence: "low"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Biggest asset",
      value: "MASQ UH (Mashreqbank)",
      confidence: "high"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Group revenue",
      value: "~$4B (2023)",
      confidence: "medium"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Group stake",
      value: "~85% of Al Ghurair Inv.",
      confidence: "medium",
      style: {
        borderBottom: "none"
      }
    })), /*#__PURE__*/React.createElement(CardFooter, null, /*#__PURE__*/React.createElement(SourceList, {
      sources: ["Forbes Billionaires", "Bloomberg", "Arabian Business"]
    }))), /*#__PURE__*/React.createElement(Card, {
      pad: false
    }, /*#__PURE__*/React.createElement(CardHeader, {
      icon: /*#__PURE__*/React.createElement(I.Building, {
        size: 16
      }),
      title: "Business Empire",
      action: /*#__PURE__*/React.createElement("span", {
        style: {
          display: "flex",
          alignItems: "center",
          gap: 10,
          fontSize: 12.5,
          color: "var(--text-tertiary)"
        }
      }, /*#__PURE__*/React.createElement("span", {
        style: {
          fontWeight: 600
        }
      }, "10 BUSINESSES"), /*#__PURE__*/React.createElement(ConfidencePill, {
        level: "high"
      }, "91% confidence"))
    }), /*#__PURE__*/React.createElement(CardBody, null, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 12,
        padding: "12px 0",
        borderBottom: "1px solid var(--border-subtle)"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 34,
        height: 34,
        borderRadius: 9,
        background: "var(--surface-sunken)",
        border: "1px solid var(--border-subtle)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "var(--ink-500)",
        flex: "0 0 auto"
      }
    }, /*#__PURE__*/React.createElement(I.Building, {
      size: 17
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement("b", {
      style: {
        fontSize: 14
      }
    }, "Mashreqbank"), /*#__PURE__*/React.createElement(Badge, {
      tone: "accent"
    }, "Founded 1967")), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "var(--text-secondary)",
        marginTop: 2
      }
    }, "UAE's first private bank \xB7 stepped down 2019"))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 12,
        padding: "12px 0"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        width: 34,
        height: 34,
        borderRadius: 9,
        background: "var(--surface-sunken)",
        border: "1px solid var(--border-subtle)",
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        color: "var(--ink-500)",
        flex: "0 0 auto"
      }
    }, /*#__PURE__*/React.createElement(I.Store, {
      size: 17
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1
      }
    }, /*#__PURE__*/React.createElement("b", {
      style: {
        fontSize: 14
      }
    }, "Al Ghurair Food (Jenan)"), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "var(--text-secondary)",
        marginTop: 2
      }
    }, "UAE's largest flour mill \xB7 pasta, oils \xB7 20+ countries")))), /*#__PURE__*/React.createElement(CardFooter, null, /*#__PURE__*/React.createElement(SourceList, {
      sources: ["Al Ghurair Inv.", "Mashreq IR", "Reuters", "The National"]
    }))), /*#__PURE__*/React.createElement(Card, {
      pad: false
    }, /*#__PURE__*/React.createElement(CardHeader, {
      icon: /*#__PURE__*/React.createElement(I.Handshake, {
        size: 16
      }),
      title: "Philanthropy \u2014 AGF",
      action: /*#__PURE__*/React.createElement(ConfidencePill, {
        level: "medium"
      }, "86% confidence")
    }), /*#__PURE__*/React.createElement(CardBody, null, /*#__PURE__*/React.createElement(FieldRow, {
      label: "Founded",
      value: "2015",
      confidence: "high"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Total pledge",
      value: "AED 4.2B ($1.1B)",
      emphasis: "brand",
      confidence: "low"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Share of wealth",
      value: "One-third",
      confidence: "low"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Learners reached",
      value: "261,000+",
      confidence: "high"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Countries",
      value: "22+ Arab nations",
      confidence: "high"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Focus",
      value: "STEM, vocational, digital",
      confidence: "high"
    }), /*#__PURE__*/React.createElement(FieldRow, {
      label: "Key honour",
      value: "1st ALECSO Edu. Ambassador",
      confidence: "high",
      style: {
        borderBottom: "none"
      }
    })), /*#__PURE__*/React.createElement(CardFooter, null, /*#__PURE__*/React.createElement(SourceList, {
      sources: ["AGFund.org", "ALECSO", "Khaleej Times"]
    }))), /*#__PURE__*/React.createElement(Card, {
      pad: false
    }, /*#__PURE__*/React.createElement(CardHeader, {
      icon: /*#__PURE__*/React.createElement(I.Quote, {
        size: 16
      }),
      title: "In His Own Words",
      action: /*#__PURE__*/React.createElement(ConfidencePill, {
        level: "high"
      }, "95% confidence")
    }), /*#__PURE__*/React.createElement(CardBody, null, /*#__PURE__*/React.createElement("blockquote", {
      style: {
        margin: "6px 0",
        padding: "4px 0 4px 16px",
        borderLeft: "3px solid var(--coral-500)"
      }
    }, /*#__PURE__*/React.createElement("p", {
      style: {
        margin: 0,
        fontSize: 16,
        lineHeight: 1.5,
        color: "var(--text-primary)"
      }
    }, "\u201CSeeking an education is not only about personal achievement but also our civic and religious responsibility as Arabs and Muslims.\u201D"), /*#__PURE__*/React.createElement("cite", {
      style: {
        display: "block",
        marginTop: 10,
        fontStyle: "normal",
        fontSize: 13,
        color: "var(--text-secondary)"
      }
    }, "\u2014 AGF Foundation mission"))), /*#__PURE__*/React.createElement(CardFooter, null, /*#__PURE__*/React.createElement(SourceList, {
      sources: ["AGF Press Release", "Interview · The National (2016)"]
    }))), /*#__PURE__*/React.createElement(Card, {
      pad: false
    }, /*#__PURE__*/React.createElement(CardHeader, {
      icon: /*#__PURE__*/React.createElement(I.Gem, {
        size: 16
      }),
      title: "Key Milestones",
      action: /*#__PURE__*/React.createElement(ConfidencePill, {
        level: "medium"
      }, "88% confidence")
    }), /*#__PURE__*/React.createElement(CardBody, null, [["1960", "Co-founds Al Ghurair Group"], ["1967", "Launches Mashreqbank"], ["1981", "First ATMs in UAE"]].map(([y, t], i, a) => /*#__PURE__*/React.createElement("div", {
      key: y,
      style: {
        display: "flex",
        gap: 16,
        alignItems: "center",
        padding: "12px 0",
        borderBottom: i < a.length - 1 ? "1px solid var(--border-subtle)" : "none"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        width: 6,
        height: 6,
        borderRadius: "50%",
        background: "var(--coral-500)",
        flex: "0 0 auto"
      }
    }), /*#__PURE__*/React.createElement("b", {
      style: {
        fontSize: 14,
        color: "var(--coral-600)",
        width: 48
      }
    }, y), /*#__PURE__*/React.createElement("span", {
      style: {
        fontSize: 14
      }
    }, t)))), /*#__PURE__*/React.createElement(CardFooter, null, /*#__PURE__*/React.createElement(SourceList, {
      sources: ["Mashreq Archives", "Wikipedia", "Gulf Business"]
    }))));
  }
  function EmptyIntel({
    name,
    onRun
  }) {
    return /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        flexDirection: "column",
        alignItems: "center",
        justifyContent: "center",
        padding: "80px 20px",
        textAlign: "center"
      }
    }, /*#__PURE__*/React.createElement(ProductMark, {
      glyph: /*#__PURE__*/React.createElement(I.Sparkles, {
        size: 30
      }),
      tone: "dark",
      size: 64,
      style: {
        borderRadius: 18,
        boxShadow: "var(--shadow-lg)"
      }
    }), /*#__PURE__*/React.createElement("h2", {
      style: {
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        fontSize: 28,
        letterSpacing: "-0.02em",
        margin: "22px 0 10px"
      }
    }, "No intelligence on ", name.split(" ")[0], " yet"), /*#__PURE__*/React.createElement("p", {
      style: {
        color: "var(--text-secondary)",
        fontSize: 15,
        lineHeight: 1.5,
        maxWidth: 480,
        margin: "0 0 22px"
      }
    }, "Add what you already know \u2014 where you met, what they're working on, why they matter \u2014 and I'll pull the rest from the web, LinkedIn, X, and more."), /*#__PURE__*/React.createElement(Button, {
      size: "lg",
      iconLeft: /*#__PURE__*/React.createElement(I.Sparkles, {
        size: 17
      }),
      onClick: onRun
    }, "Run Intelligence"), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 6,
        marginTop: 16,
        color: "var(--text-tertiary)",
        fontSize: 13
      }
    }, /*#__PURE__*/React.createElement(I.Help, {
      size: 14
    }), " Usually takes ~12 seconds"));
  }
  function ContactView({
    person,
    onBack
  }) {
    const [tab, setTab] = React.useState("Intelligence");
    const [ran, setRan] = React.useState(person.id !== "olive");
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "20px 26px 40px"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 18,
        alignItems: "flex-start"
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: person.name,
      index: person.idx,
      size: 84
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        flex: 1,
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("h1", {
      style: {
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        fontSize: 30,
        letterSpacing: "-0.02em",
        margin: 0
      }
    }, person.name), /*#__PURE__*/React.createElement(Badge, {
      tone: "success",
      dot: true
    }, person.status), /*#__PURE__*/React.createElement(Badge, {
      tone: "accent"
    }, person.type), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--text-tertiary)"
      }
    }, /*#__PURE__*/React.createElement(I.Lock, {
      size: 16
    }))), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 15,
        color: "var(--text-secondary)",
        marginTop: 4
      }
    }, /*#__PURE__*/React.createElement("b", {
      style: {
        color: "var(--text-primary)",
        fontWeight: 600
      }
    }, person.title), " ", person.company), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        marginTop: 12,
        flexWrap: "wrap"
      }
    }, /*#__PURE__*/React.createElement("span", {
      style: contactChip
    }, /*#__PURE__*/React.createElement(I.MapPin, {
      size: 14
    }), " ", person.loc), /*#__PURE__*/React.createElement("span", {
      style: contactChip
    }, /*#__PURE__*/React.createElement(I.Mail, {
      size: 14
    }), " ", person.id, "@", person.company.toLowerCase().replace(/\s/g, ""), ".com"), /*#__PURE__*/React.createElement("span", {
      style: contactChip
    }, "in/", person.id), /*#__PURE__*/React.createElement("span", {
      style: contactChip
    }, "@", person.id))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8,
        alignItems: "center",
        flex: "0 0 auto"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        marginRight: 4
      }
    }, [0, 1, 2].map(i => /*#__PURE__*/React.createElement(Avatar, {
      key: i,
      name: ["Tom D", "Dana R", "Raj K"][i],
      index: i,
      size: "sm",
      style: {
        marginLeft: i ? -8 : 0,
        boxShadow: "0 0 0 2px var(--surface-card)"
      }
    })), /*#__PURE__*/React.createElement("div", {
      style: {
        width: 32,
        height: 32,
        borderRadius: "50%",
        background: "var(--ink-100)",
        border: "2px solid var(--surface-card)",
        marginLeft: -8,
        display: "flex",
        alignItems: "center",
        justifyContent: "center",
        fontSize: 11,
        fontWeight: 600,
        color: "var(--ink-500)"
      }
    }, "+4")), /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      iconLeft: /*#__PURE__*/React.createElement(I.Plus, {
        size: 15
      }),
      iconRight: /*#__PURE__*/React.createElement(I.ChevronDown, {
        size: 14
      })
    }, "Add"), /*#__PURE__*/React.createElement(IconButton, {
      icon: /*#__PURE__*/React.createElement(I.More, {
        size: 18
      }),
      variant: "outline",
      label: "More"
    }), /*#__PURE__*/React.createElement(Button, {
      variant: "dark",
      iconLeft: /*#__PURE__*/React.createElement(I.Sparkles, {
        size: 15
      }),
      onClick: () => setRan(true)
    }, "Run Intelligence"))), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        marginTop: 22,
        padding: "14px 0",
        borderTop: "1px solid var(--border-subtle)",
        borderBottom: "1px solid var(--border-subtle)"
      }
    }, /*#__PURE__*/React.createElement(StatCell, {
      label: "Relationship",
      ai: true
    }, /*#__PURE__*/React.createElement(StrengthMeter, {
      value: person.strength,
      label: person.sLabel
    })), /*#__PURE__*/React.createElement(StatCell, {
      label: "Record owner"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 6,
        fontWeight: 600
      }
    }, "Juan Esparto ", /*#__PURE__*/React.createElement(I.ChevronDown, {
      size: 15,
      style: {
        color: "var(--ink-400)"
      }
    }))), /*#__PURE__*/React.createElement(StatCell, {
      label: "Net worth",
      ai: true
    }, /*#__PURE__*/React.createElement("span", {
      style: {
        fontWeight: 700,
        fontSize: 18
      }
    }, "$4.4B")), /*#__PURE__*/React.createElement(StatCell, {
      label: "Focus areas"
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 6,
        flexWrap: "wrap"
      }
    }, person.focus.concat(["Consumer"]).map(f => /*#__PURE__*/React.createElement(Chip, {
      key: f
    }, f)))), /*#__PURE__*/React.createElement(StatCell, {
      label: "Last interaction"
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("b", {
      style: {
        fontWeight: 600
      }
    }, person.last), " ", /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--text-tertiary)",
        fontSize: 13
      }
    }, "by Yasir Drabu")))), /*#__PURE__*/React.createElement("div", {
      style: {
        marginTop: 8,
        marginBottom: 20
      }
    }, /*#__PURE__*/React.createElement(Tabs, {
      tabs: ["Overview", "Network", "Profile", "Intelligence", "Documents", "Notes"],
      value: tab,
      onChange: setTab
    })), ran ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement(Overview, null), /*#__PURE__*/React.createElement(IntelGrid, null)) : /*#__PURE__*/React.createElement(EmptyIntel, {
      name: person.name,
      onRun: () => setRan(true)
    }));
  }
  window.KContactView = ContactView;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/kindle/ContactView.jsx", error: String((e && e.message) || e) }); }

// ui_kits/kindle/PeopleList.jsx
try { (() => {
// Kindle — People list view.
(function () {
  const NS = window.DaykoDesignSystem_0082b9;
  const {
    Avatar,
    Badge,
    Chip,
    StrengthMeter,
    Button,
    IconButton
  } = NS;
  const I = window.KIcons;
  const PEOPLE = [{
    id: "abdullah",
    name: "Abdullah bin Ahmed",
    title: "CEO",
    company: "Mashreqbank",
    loc: "Dubai, UAE",
    strength: 5,
    sLabel: "Strong",
    status: "Active",
    type: "Partner",
    focus: ["AI", "SaaS", "Crypto"],
    last: "3 days ago",
    idx: 1
  }, {
    id: "olive",
    name: "Olive Bennett",
    title: "Head of Growth",
    company: "Northwind Labs",
    loc: "London, UK",
    strength: 5,
    sLabel: "Very Strong",
    status: "Active",
    type: "Partner",
    focus: ["AI", "SaaS"],
    last: "3 days ago",
    idx: 0
  }, {
    id: "sarah",
    name: "Sarah Chen",
    title: "Partner",
    company: "Meridian Capital",
    loc: "New York, NY",
    strength: 4,
    sLabel: "Strong",
    status: "Active",
    type: "Investor",
    focus: ["Fintech", "AI"],
    last: "Today",
    idx: 4
  }, {
    id: "tomr",
    name: "Tom Rivera",
    title: "VP Product",
    company: "Lumen",
    loc: "Austin, TX",
    strength: 2,
    sLabel: "Moderate",
    status: "Active",
    type: "Customer",
    focus: ["SaaS"],
    last: "1 week ago",
    idx: 2
  }, {
    id: "priya",
    name: "Priya Menon",
    title: "Design Lead",
    company: "Arc Studio",
    loc: "Bangalore, IN",
    strength: 3,
    sLabel: "Building",
    status: "Prospect",
    type: "Lead",
    focus: ["Consumer"],
    last: "2 weeks ago",
    idx: 3
  }, {
    id: "juan",
    name: "Juan Esparto",
    title: "Managing Director",
    company: "Esparto Group",
    loc: "Madrid, ES",
    strength: 4,
    sLabel: "Strong",
    status: "Active",
    type: "Partner",
    focus: ["PE", "Crypto"],
    last: "yesterday",
    idx: 1
  }];
  const th = {
    textAlign: "left",
    fontSize: 11,
    fontWeight: 600,
    letterSpacing: "0.06em",
    textTransform: "uppercase",
    color: "var(--text-tertiary)",
    padding: "0 16px",
    height: 40,
    whiteSpace: "nowrap"
  };
  const td = {
    padding: "12px 16px",
    borderTop: "1px solid var(--border-subtle)",
    verticalAlign: "middle"
  };
  function PeopleList({
    onOpen
  }) {
    const [hover, setHover] = React.useState(null);
    return /*#__PURE__*/React.createElement("div", {
      style: {
        padding: "22px 26px"
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        justifyContent: "space-between",
        marginBottom: 18
      }
    }, /*#__PURE__*/React.createElement("div", null, /*#__PURE__*/React.createElement("h1", {
      style: {
        fontFamily: "var(--font-display)",
        fontWeight: 700,
        fontSize: 26,
        letterSpacing: "-0.02em",
        margin: 0
      }
    }, "People"), /*#__PURE__*/React.createElement("p", {
      style: {
        color: "var(--text-secondary)",
        fontSize: 14,
        margin: "4px 0 0"
      }
    }, PEOPLE.length, " contacts \xB7 updated automatically by Ray")), /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 8
      }
    }, /*#__PURE__*/React.createElement(Button, {
      variant: "secondary",
      iconLeft: /*#__PURE__*/React.createElement(I.Search, {
        size: 15
      })
    }, "Filter"), /*#__PURE__*/React.createElement(Button, {
      variant: "dark",
      iconLeft: /*#__PURE__*/React.createElement(I.Sparkles, {
        size: 15
      })
    }, "Run Intelligence"))), /*#__PURE__*/React.createElement("div", {
      style: {
        background: "var(--surface-card)",
        border: "1px solid var(--border-subtle)",
        borderRadius: "var(--radius-lg)",
        boxShadow: "var(--shadow-sm)",
        overflow: "hidden"
      }
    }, /*#__PURE__*/React.createElement("table", {
      style: {
        width: "100%",
        borderCollapse: "collapse"
      }
    }, /*#__PURE__*/React.createElement("thead", null, /*#__PURE__*/React.createElement("tr", null, /*#__PURE__*/React.createElement("th", {
      style: {
        ...th,
        paddingLeft: 20
      }
    }, "Name"), /*#__PURE__*/React.createElement("th", {
      style: th
    }, "Relationship"), /*#__PURE__*/React.createElement("th", {
      style: th
    }, "Focus areas"), /*#__PURE__*/React.createElement("th", {
      style: th
    }, "Status"), /*#__PURE__*/React.createElement("th", {
      style: {
        ...th,
        textAlign: "right",
        paddingRight: 20
      }
    }, "Last interaction"))), /*#__PURE__*/React.createElement("tbody", null, PEOPLE.map(p => /*#__PURE__*/React.createElement("tr", {
      key: p.id,
      onClick: () => onOpen && onOpen(p.id),
      onMouseEnter: () => setHover(p.id),
      onMouseLeave: () => setHover(null),
      style: {
        cursor: "pointer",
        background: hover === p.id ? "var(--surface-hover)" : "transparent"
      }
    }, /*#__PURE__*/React.createElement("td", {
      style: {
        ...td,
        paddingLeft: 20
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        alignItems: "center",
        gap: 12
      }
    }, /*#__PURE__*/React.createElement(Avatar, {
      name: p.name,
      index: p.idx,
      size: "md"
    }), /*#__PURE__*/React.createElement("div", {
      style: {
        minWidth: 0
      }
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 14.5,
        fontWeight: 600
      }
    }, p.name), /*#__PURE__*/React.createElement("div", {
      style: {
        fontSize: 13,
        color: "var(--text-secondary)"
      }
    }, p.title, " \xB7 ", p.company)))), /*#__PURE__*/React.createElement("td", {
      style: td
    }, /*#__PURE__*/React.createElement(StrengthMeter, {
      value: p.strength,
      label: p.sLabel
    })), /*#__PURE__*/React.createElement("td", {
      style: td
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 6,
        flexWrap: "wrap"
      }
    }, p.focus.map(f => /*#__PURE__*/React.createElement(Chip, {
      key: f
    }, f)))), /*#__PURE__*/React.createElement("td", {
      style: td
    }, /*#__PURE__*/React.createElement("div", {
      style: {
        display: "flex",
        gap: 6,
        alignItems: "center"
      }
    }, /*#__PURE__*/React.createElement(Badge, {
      tone: p.status === "Active" ? "success" : "neutral",
      dot: true
    }, p.status), /*#__PURE__*/React.createElement(Badge, {
      tone: "accent"
    }, p.type))), /*#__PURE__*/React.createElement("td", {
      style: {
        ...td,
        textAlign: "right",
        paddingRight: 20,
        color: "var(--text-secondary)",
        fontSize: 13.5,
        whiteSpace: "nowrap"
      }
    }, p.last)))))));
  }
  window.KPeopleList = PeopleList;
  window.KPeople = PEOPLE;
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/kindle/PeopleList.jsx", error: String((e && e.message) || e) }); }

// ui_kits/kindle/app.jsx
try { (() => {
// Kindle UI kit — interactive orchestrator.
(function () {
  const I = window.KIcons;
  const AppShell = window.KAppShell,
    AuthScreen = window.KAuthScreen,
    PeopleList = window.KPeopleList,
    ContactView = window.KContactView,
    PEOPLE = window.KPeople;
  function App() {
    const [authed, setAuthed] = React.useState(false);
    const [nav, setNav] = React.useState("People");
    const [openId, setOpenId] = React.useState(null);
    const person = openId ? PEOPLE.find(p => p.id === openId) : null;
    if (!authed) return /*#__PURE__*/React.createElement(AuthScreen, {
      onContinue: () => setAuthed(true)
    });
    const crumb = person ? /*#__PURE__*/React.createElement(React.Fragment, null, /*#__PURE__*/React.createElement("span", {
      onClick: () => setOpenId(null),
      style: {
        cursor: "pointer",
        display: "inline-flex",
        alignItems: "center",
        gap: 6
      }
    }, /*#__PURE__*/React.createElement(I.ChevronLeft, {
      size: 16
    }), " People"), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--ink-300)"
      }
    }, "/"), /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--text-primary)",
        fontWeight: 600
      }
    }, person.name.split(" ")[0], " ", person.name.split(" ").slice(-1)[0][0], ".")) : /*#__PURE__*/React.createElement("span", {
      style: {
        color: "var(--text-primary)",
        fontWeight: 600
      }
    }, nav);
    return /*#__PURE__*/React.createElement(AppShell, {
      nav: nav,
      breadcrumb: crumb,
      search: person && person.id === "olive" ? "Ask Ray…." : "Search anything….",
      onNav: n => {
        setNav(n);
        setOpenId(null);
      }
    }, person ? /*#__PURE__*/React.createElement(ContactView, {
      person: person,
      onBack: () => setOpenId(null)
    }) : nav === "People" ? /*#__PURE__*/React.createElement(PeopleList, {
      onOpen: id => setOpenId(id)
    }) : /*#__PURE__*/React.createElement("div", {
      style: {
        padding: 40,
        color: "var(--text-secondary)"
      }
    }, nav, " \u2014 sample view"));
  }
  ReactDOM.createRoot(document.getElementById("root")).render(/*#__PURE__*/React.createElement(App, null));
})();
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/kindle/app.jsx", error: String((e && e.message) || e) }); }

// ui_kits/kindle/icons.jsx
try { (() => {
// Kindle UI kit — shared inline icons (Lucide-family, closest match to the
// product's line-icon set). Exposed on window.KIcons for the babel scripts.
const _S = (paths, sw) => props => {
  const s = props && props.size ? props.size : 18;
  return React.createElement("svg", {
    width: s,
    height: s,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: sw || 1.8,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: props && props.style
  }, paths.map((d, i) => React.createElement("path", {
    key: i,
    d
  })));
};
const _C = (children, sw) => props => {
  const s = props && props.size ? props.size : 18;
  return React.createElement("svg", {
    width: s,
    height: s,
    viewBox: "0 0 24 24",
    fill: "none",
    stroke: "currentColor",
    strokeWidth: sw || 1.8,
    strokeLinecap: "round",
    strokeLinejoin: "round",
    style: props && props.style
  }, children);
};
const c = React.createElement;
window.KIcons = {
  Home: _S(["M3 10.5 12 3l9 7.5", "M5 9.5V21h14V9.5"]),
  Users: _C([c("path", {
    key: 0,
    d: "M16 21v-2a4 4 0 0 0-4-4H6a4 4 0 0 0-4 4v2"
  }), c("circle", {
    key: 1,
    cx: 9,
    cy: 7,
    r: 4
  }), c("path", {
    key: 2,
    d: "M22 21v-2a4 4 0 0 0-3-3.87"
  }), c("path", {
    key: 3,
    d: "M16 3.13a4 4 0 0 1 0 7.75"
  })]),
  Building: _C([c("rect", {
    key: 0,
    x: 4,
    y: 3,
    width: 16,
    height: 18,
    rx: 1.5
  }), c("path", {
    key: 1,
    d: "M9 21v-4h6v4M8 7h.01M12 7h.01M16 7h.01M8 11h.01M12 11h.01M16 11h.01M8 15h.01M16 15h.01"
  })]),
  Calendar: _C([c("rect", {
    key: 0,
    x: 3,
    y: 4,
    width: 18,
    height: 17,
    rx: 2
  }), c("path", {
    key: 1,
    d: "M3 9h18M8 2v4M16 2v4"
  })]),
  Message: _S(["M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"]),
  Settings: _C([c("circle", {
    key: 0,
    cx: 12,
    cy: 12,
    r: 3
  }), c("path", {
    key: 1,
    d: "M12 2v2M12 20v2M4.9 4.9l1.4 1.4M17.7 17.7l1.4 1.4M2 12h2M20 12h2M4.9 19.1l1.4-1.4M17.7 6.3l1.4-1.4"
  })]),
  Help: _C([c("circle", {
    key: 0,
    cx: 12,
    cy: 12,
    r: 9
  }), c("path", {
    key: 1,
    d: "M9.1 9a3 3 0 0 1 5.8 1c0 2-3 3-3 3"
  }), c("path", {
    key: 2,
    d: "M12 17h.01"
  })]),
  Link: _S(["M10 13a5 5 0 0 0 7.54.54l3-3a5 5 0 0 0-7.07-7.07l-1.72 1.71", "M14 11a5 5 0 0 0-7.54-.54l-3 3a5 5 0 0 0 7.07 7.07l1.71-1.71"]),
  Plus: _S(["M12 5v14M5 12h14"]),
  ChevronDown: _S(["m6 9 6 6 6-6"]),
  ChevronRight: _S(["m9 18 6-6-6-6"]),
  ChevronLeft: _S(["m15 18-6-6 6-6"]),
  More: _C([c("circle", {
    key: 0,
    cx: 12,
    cy: 5,
    r: 1
  }), c("circle", {
    key: 1,
    cx: 12,
    cy: 12,
    r: 1
  }), c("circle", {
    key: 2,
    cx: 12,
    cy: 19,
    r: 1
  })]),
  Search: _C([c("circle", {
    key: 0,
    cx: 11,
    cy: 11,
    r: 7
  }), c("path", {
    key: 1,
    d: "m21 21-4.3-4.3"
  })]),
  MapPin: _C([c("path", {
    key: 0,
    d: "M20 10c0 6-8 12-8 12s-8-6-8-12a8 8 0 0 1 16 0Z"
  }), c("circle", {
    key: 1,
    cx: 12,
    cy: 10,
    r: 3
  })]),
  Mail: _C([c("rect", {
    key: 0,
    x: 3,
    y: 5,
    width: 18,
    height: 14,
    rx: 2
  }), c("path", {
    key: 1,
    d: "m3 7 9 6 9-6"
  })]),
  Lock: _C([c("rect", {
    key: 0,
    x: 5,
    y: 11,
    width: 14,
    height: 10,
    rx: 2
  }), c("path", {
    key: 1,
    d: "M8 11V7a4 4 0 0 1 8 0v4"
  })]),
  Sparkles: _S(["M12 3v4M12 17v4M3 12h4M17 12h4", "M6.3 6.3l2.4 2.4M15.3 15.3l2.4 2.4M17.7 6.3l-2.4 2.4M8.7 15.3l-2.4 2.4"], 1.7),
  Layers: _S(["m12 2 9 5-9 5-9-5 9-5Z", "m3 12 9 5 9-5", "m3 17 9 5 9-5"]),
  Bolt: _S(["M13 2 4.5 13.5H12l-1 8.5L19.5 10.5H12l1-8.5Z"]),
  Sidebar: _C([c("rect", {
    key: 0,
    x: 3,
    y: 4,
    width: 18,
    height: 16,
    rx: 2
  }), c("path", {
    key: 1,
    d: "M9 4v16"
  })]),
  User: _C([c("path", {
    key: 0,
    d: "M19 21v-2a4 4 0 0 0-4-4H9a4 4 0 0 0-4 4v2"
  }), c("circle", {
    key: 1,
    cx: 12,
    cy: 7,
    r: 4
  })]),
  Briefcase: _C([c("rect", {
    key: 0,
    x: 3,
    y: 7,
    width: 18,
    height: 13,
    rx: 2
  }), c("path", {
    key: 1,
    d: "M8 7V5a2 2 0 0 1 2-2h4a2 2 0 0 1 2 2v2M3 13h18"
  })]),
  Quote: _S(["M6 11H4a1 1 0 0 1-1-1V8a3 3 0 0 1 3-3M14 11h-2a1 1 0 0 1-1-1V8a3 3 0 0 1 3-3"]),
  Store: _S(["M4 9h16l-1-5H5L4 9Z", "M4 9v10a1 1 0 0 0 1 1h14a1 1 0 0 0 1-1V9"]),
  Zap: _S(["M13 2 4.5 13.5H12l-1 8.5L19.5 10.5H12l1-8.5Z"]),
  Copy: _C([c("rect", {
    key: 0,
    x: 9,
    y: 9,
    width: 12,
    height: 12,
    rx: 2
  }), c("path", {
    key: 1,
    d: "M5 15H4a2 2 0 0 1-2-2V4a2 2 0 0 1 2-2h9a2 2 0 0 1 2 2v1"
  })]),
  Handshake: _S(["m11 17 2 2a1 1 0 0 0 1.4 0l3.6-3.6", "M14 8.5 12 6.5a1 1 0 0 0-1.4 0L7 10l3 3", "M3 12l4-4M21 12l-4-4"]),
  Gem: _S(["M6 3h12l4 6-10 12L2 9l4-6Z", "M2 9h20M12 3 8 9l4 12 4-12-4-6"])
};
})(); } catch (e) { __ds_ns.__errors.push({ path: "ui_kits/kindle/icons.jsx", error: String((e && e.message) || e) }); }

__ds_ns.Avatar = __ds_scope.Avatar;

__ds_ns.Badge = __ds_scope.Badge;

__ds_ns.Button = __ds_scope.Button;

__ds_ns.Card = __ds_scope.Card;

__ds_ns.CardHeader = __ds_scope.CardHeader;

__ds_ns.CardBody = __ds_scope.CardBody;

__ds_ns.CardFooter = __ds_scope.CardFooter;

__ds_ns.Chip = __ds_scope.Chip;

__ds_ns.IconButton = __ds_scope.IconButton;

__ds_ns.ProductMark = __ds_scope.ProductMark;

__ds_ns.ConfidenceDot = __ds_scope.ConfidenceDot;

__ds_ns.ConfidencePill = __ds_scope.ConfidencePill;

__ds_ns.FieldRow = __ds_scope.FieldRow;

__ds_ns.SourceList = __ds_scope.SourceList;

__ds_ns.StrengthMeter = __ds_scope.StrengthMeter;

__ds_ns.Input = __ds_scope.Input;

__ds_ns.SearchBar = __ds_scope.SearchBar;

__ds_ns.SidebarItem = __ds_scope.SidebarItem;

__ds_ns.SidebarNav = __ds_scope.SidebarNav;

__ds_ns.Tabs = __ds_scope.Tabs;

})();
